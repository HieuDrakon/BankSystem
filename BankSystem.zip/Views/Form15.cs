﻿using BankDB.Controllers;
using BankDB.Models;
using System;
using _Banking.Controller;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Banking.Views
{
    public partial class Form15 : Form, IView
    {
        CustomerController _customerController;
        public Form15()
        {
            InitializeComponent();
        }
        public void SetDataToText(object item)
        {

        }

        // Phương thức này lấy dữ liệu từ các TextBox và trả về một đối tượng `Customer`
        public object GetDataFromText()
        {
            return new Customer
            {

                Name = txtCustomerName.Text,
                Phone = txtCustomerPhone.Text,
                Email = txtCustomerEmail.Text,
                HouseNo = txtCustomerHouseNo.Text,
                City = txtCustomerCity.Text,
                Pin = txtCustomerPin.Text
            };
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Customer customer = (Customer)GetDataFromText();
            if (_customerController.Create(customer))
            {
                MessageBox.Show(" Đăng ký thành công");
            }
            else
            {
                MessageBox.Show("Vui lòng nhập đúng thông tin đăng ký ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form13 f13 = new Form13();
            f13.Show();
            this.Hide();
        }
    }
}
