﻿using _Banking.Controller;
using BankDB.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Banking.Views
{
    public partial class Form16 : Form
    {
        TransactionController transactionController;
        public Form16()
        {
            InitializeComponent();
            transactionController = new TransactionController();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            DisplayTransactions(UserSession.ID);
        }
        private void DisplayTransactions(string id)
        {
            // Lấy danh sách các giao dịch với ID = 1
            var transactions = transactionController.GetTransactionsById(id);

            // Hiển thị trong DataGridView
            dataGridView1.DataSource = transactions.Select(t => new
            {
                t.Id,
                t.FromAccountId,
                t.ToAccountId,
                t.Amount,
                t.DateOfTrans,
                t.Pin,
                t.BranchId,
                t.EmployeeId
            }).ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }
    }
}
