﻿namespace _Banking.Views
{
    partial class Form10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            txtAccountId = new TextBox();
            button1 = new Button();
            button2 = new Button();
            lblStatus = new Label();
            groupBox1 = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            button3 = new Button();
            button5 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Highlight;
            label3.Location = new Point(224, 25);
            label3.Name = "label3";
            label3.Size = new Size(317, 46);
            label3.TabIndex = 14;
            label3.Text = "BALANCE AMOUNT";
            // 
            // txtAccountId
            // 
            txtAccountId.Location = new Point(275, 135);
            txtAccountId.Name = "txtAccountId";
            txtAccountId.Size = new Size(197, 27);
            txtAccountId.TabIndex = 9;
            // 
            // button1
            // 
            button1.Location = new Point(247, 243);
            button1.Name = "button1";
            button1.Size = new Size(73, 29);
            button1.TabIndex = 10;
            button1.Text = "Check ";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(336, 243);
            button2.Name = "button2";
            button2.Size = new Size(82, 29);
            button2.TabIndex = 11;
            button2.Text = "Deposit";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(19, 28);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "label1";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(115, 297);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(426, 125);
            groupBox1.TabIndex = 12;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(187, 138);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 8;
            label1.Text = "AccountID ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(275, 180);
            label2.Name = "label2";
            label2.Size = new Size(45, 20);
            label2.TabIndex = 15;
            label2.Text = "None";
            // 
            // button3
            // 
            button3.Location = new Point(437, 243);
            button3.Name = "button3";
            button3.Size = new Size(82, 29);
            button3.TabIndex = 16;
            button3.Text = "Withdraw";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button5
            // 
            button5.Location = new Point(-1, 2);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 29;
            button5.Text = "Back";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form10
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.d52078bfddc4e60232af4e8846262446;
            ClientSize = new Size(611, 450);
            Controls.Add(button5);
            Controls.Add(button3);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtAccountId);
            Name = "Form10";
            Text = "Form10";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private TextBox txtAccountId;
        private Button button1;
        private Button button2;
        private Label lblStatus;
        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private Button button3;
        private Button button5;
    }
}