﻿using _Banking.Controller;
using BankDB.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace _Banking.Views
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var email = txtEmail.Text;
            var password = txtPassword.Text;

            EmployeeController employeeController = new EmployeeController();
            string userrole = employeeController.Login(email, password);

            if (userrole != null)
            {
                MessageBox.Show("Đăng nhập thành công!");
                Form2 menu = new Form2(userrole);
                UserSession.SetUserRole(userrole);
                menu.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Email hoặc mật khẩu không đúng.");
            }
        }

        private void lblRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var registerForm = new Form5();
            registerForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 registerForm = new Form5();

            // Hiển thị Form2
            registerForm.Show();

            // Đóng Form1 nếu cần thiết (nếu bạn muốn ẩn form đăng nhập)
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }

}
