﻿using _Banking.Controller;
using BankDB.Controllers;

namespace _Banking.Views
{
    public partial class Form9 : Form
    {
        private WithdrawController _withdrawController;

        public Form9()
        {
            InitializeComponent();
            _withdrawController = new WithdrawController();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string accountId = txtAccountId.Text; // Lấy ID tài khoản từ textbox
            double amount;

            // Kiểm tra xem số tiền nhập vào có phải là một số hợp lệ không
            if (double.TryParse(txtAmount.Text, out amount) && amount > 0)
            {
                bool success = _withdrawController.WithdrawAmount(accountId, amount);

                if (success)
                {
                    lblStatus.Text = "Rút tiền thành công!";
                    MessageBox.Show("Rút tiền thành công!");
                }
                else
                {
                    lblStatus.Text = "Số dư không đủ hoặc tài khoản không tồn tại.";
                    MessageBox.Show("Số dư không đủ hoặc tài khoản không tồn tại.");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số tiền hợp lệ.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }
    }
}
