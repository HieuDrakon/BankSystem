﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Banking.Views
{
    public partial class Form2 : Form
    {
        public Form2(string userRole)
        {
            InitializeComponent();
            HideSystemSection(userRole);
        }
        private void HideSystemSection(string role)
        {
            if (role.Equals("NV", StringComparison.OrdinalIgnoreCase))
            {
                toolStripButton4.Enabled = false;
                toolStripButton5.Enabled = false;
                systemToolStripMenuItem.Enabled = false;

            }
            else if(role.Equals("KH", StringComparison.OrdinalIgnoreCase))
            {
                toolStripButton4.Enabled = false;
                toolStripButton5.Enabled = false;
                toolStripButton6.Enabled = false;
                toolStripButton7.Enabled = false;
                systemToolStripMenuItem.Enabled = false;
                createCustomerToolStripMenuItem.Enabled = false;
                createAccountToolStripMenuItem.Enabled = false;
            }
        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Form4 customer = new Form4();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            Form11 customer = new Form11();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton14_Click(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void SytemTool_Click(object sender, EventArgs e)
        {

        }

        private void createCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 customer = new Form1();
            customer.Show();
            this.Hide();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 customer = new Form4();
            customer.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void createAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 customer = new Form7();
            customer.Show();
            this.Hide();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 customer = new Form6();
            customer.Show();
            this.Hide();
        }

        private void depositToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form8 customer = new Form8();
            customer.Show();
            this.Hide();
        }

        private void withdrawAmountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 f9 = new Form9();
            f9.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form11 f11 = new Form11();
            f11.Show();
            this.Hide();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form4 customer = new Form4();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Form6 customer = new Form6();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Form3 customer = new Form3();
            customer.Show();
            this.Hide();
        }

        private void branchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 customer = new Form3();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            Form1 customer = new Form1();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            Form7 customer = new Form7();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            Form8 customer = new Form8();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            Form9 customer = new Form9();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton11_Click(object sender, EventArgs e)
        {
            Form10 customer = new Form10();
            customer.Show();
            this.Hide();
        }

        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            Form16 f16 = new Form16();
            f16.Show();
            this.Hide();
        }
    }
}
