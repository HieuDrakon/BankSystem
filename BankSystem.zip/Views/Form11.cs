﻿using _Banking.Controller;
using BankDB.Controllers;
using BankDB.Models;
using System;
using System.Windows.Forms;

namespace _Banking.Views
{
    public partial class Form11 : Form, IView
    {
        private TransactionController _transactionController;

        public Form11()
        {
            InitializeComponent();
            _transactionController = new TransactionController();
        }


        // Thực hiện phương thức từ IView
        public void SetDataToText(object item)
        {
            if (item is Transaction transaction)
            {
                txtFromAccountId.Text = transaction.FromAccountId;
                txtToAccountId.Text = transaction.ToAccountId;
                txtAmount.Text = transaction.Amount.ToString();
                txtPin.Text = transaction.Pin;
                txtBranchId.Text = transaction.BranchId;
                txtEmployeeId.Text = transaction.EmployeeId;
            }
        }

        // Lấy dữ liệu từ các textbox và trả về một đối tượng Transaction
        public object GetDataFromText()
        {
            return new Transaction
            {
                FromAccountId = txtFromAccountId.Text,
                ToAccountId = txtToAccountId.Text,
                Amount = double.Parse(txtAmount.Text),
                Pin = txtPin.Text,
                BranchId = txtBranchId.Text,
                EmployeeId = txtEmployeeId.Text,
                DateOfTrans = DateOnly.FromDateTime(DateTime.Now) // Ngày giao dịch hiện tại
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Sử dụng GetDataFromText để lấy đối tượng Transaction từ dữ liệu nhập vào form
            Transaction transaction = (Transaction)GetDataFromText();
            // Gọi controller để thực hiện thêm giao dịch
            bool success = _transactionController.Transfer(transaction);
            // Kiểm tra kết quả và hiển thị thông báo
            if (success)
            {
                lblStatus.Text = "Chuyển tiền thành công!";
                MessageBox.Show("Chuyển tiền thành công!");
            }
            else
            {
                lblStatus.Text = "Chuyển tiền thất bại. Kiểm tra lại thông tin!";
                MessageBox.Show("Chuyển tiền thất bại. Kiểm tra lại thông tin!");
            }
        }

        private void Form11_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(UserSession.CurrentUserRole);
            form2.Show();
            this.Hide();
        }
    }
}
