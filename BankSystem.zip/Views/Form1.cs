﻿using _Banking.Controller;
using BankDB.Controllers;
using BankDB.Models;

namespace _Banking.Views
{
    public partial class Form1 : Form, IView
    {
        private CustomerController _customerController;
        private string selectedCustomerId;
        public Form1()
        {
            InitializeComponent();
            _customerController = new CustomerController();
            dataGridView1.CellClick += dataGridView1_CellClick;
            // Gọi hàm để tải dữ liệu Customer vào DataGridView khi form load
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
          
            txtCustomerName.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerPhone.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerEmail.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerHouseNo.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerCity.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerPin.TextChanged += new EventHandler(TextBox_TextChanged);

            CheckFormValidity();
            LoadCustomerData();
        }
        private void LoadCustomerData()
        {
            if (_customerController.Load())
            {
                // Gán dữ liệu vào DataGridView nếu thành công
                var customers = _customerController.Items.Cast<Customer>().ToList();
                dataGridView1.DataSource = customers;
            }
            else
            {
                // Nếu không thành công, hiển thị thông báo lỗi
                MessageBox.Show("Không thể tải dữ liệu khách hàng.");
            }
        }
        public void SetDataToText(object item)
        {
            if (item is Customer customer)
            {
              
                txtCustomerName.Text = customer.Name;
                txtCustomerPhone.Text = customer.Phone;
                txtCustomerEmail.Text = customer.Email;
                txtCustomerHouseNo.Text = customer.HouseNo;
                txtCustomerCity.Text = customer.City;
                txtCustomerPin.Text = customer.Pin;
            }
        }

        // Phương thức này lấy dữ liệu từ các TextBox và trả về một đối tượng `Customer`
        public object GetDataFromText()
        {
            return new Customer
            {
                Name = txtCustomerName.Text,
                Phone = txtCustomerPhone.Text,
                Email = txtCustomerEmail.Text,
                HouseNo = txtCustomerHouseNo.Text,
                City = txtCustomerCity.Text,
                Pin = txtCustomerPin.Text
            };
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Kiểm tra nếu dòng được chọn là hợp lệ
            {
                // Lấy giá trị của cột "Id" từ dòng được chọn
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                if (selectedRow.DataBoundItem is Customer customer)
                {
                    SetDataToText(customer); // Hiển thị dữ liệu khách hàng lên các TextBox
                }
                // Lấy DocumentID từ hàng đã chọn
                int documentId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Lưu DocumentID vào một biến toàn cục hoặc có thể truyền vào phương thức xóa
                selectedCustomerId = documentId.ToString();
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedRow = dataGridView1.Rows[e.RowIndex];

                if (selectedRow.DataBoundItem != null)
                {
                    if (selectedRow.DataBoundItem is Customer customer)
                    {
                        customer.Email = selectedRow.Cells["Email"].Value?.ToString();
                        customer.Name = selectedRow.Cells["Name"].Value?.ToString();
                        customer.Phone = selectedRow.Cells["Phone"].Value?.ToString();
                        customer.HouseNo = selectedRow.Cells["HouseNo"].Value?.ToString();
                        customer.City = selectedRow.Cells["City"].Value?.ToString();
                        customer.Pin = selectedRow.Cells["Pin"].Value?.ToString();
                        try
                        {
                            _customerController.Update(customer);
                        }
                        catch (Exception ex)
                        {

                        }
                    }


                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Customer customer = (Customer)GetDataFromText();
            if (_customerController.Create(customer))
            {
                lblStatus.Text = "Customer added successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                lblStatus.Text = "Customer added faill because invalid content " + DateTime.Now.ToString("HH:mm:ss");
            }

            LoadCustomerData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedCustomerId))
            {
                _customerController.Delete(selectedCustomerId);
                LoadCustomerData();

                MessageBox.Show("Customer deleted successfully!");
                selectedCustomerId = null;
            }
            else
            {
                MessageBox.Show("Please select a customer to delete.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Customer customer = (Customer)GetDataFromText();
            if (_customerController.Update(customer))
            {
                lblStatus.Text = "Customer updated successfully at " + DateTime.Now.ToString("HH:mm:ss");
            } // Cập nhật thông tin khách hàng
            else
            {
                lblStatus.Text = "Customer updated fail because invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }
            LoadCustomerData(); // Tải lại dữ liệu sau khi cập nhật
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string searchId = txtSearch.Text; // Lấy từ khóa tìm kiếm từ TextBox

            if (!string.IsNullOrEmpty(searchId))
            {
                // Gọi phương thức Load(object id) từ controller để tìm kiếm
                if (_customerController.Load(searchId))
                {
                    // Lấy kết quả tìm kiếm từ Items và hiển thị trong DataGridView
                    var customer = _customerController.Items.Cast<Customer>().FirstOrDefault();
                    if (customer != null)
                    {
                        // Hiển thị thông tin khách hàng đã tìm được
                        dataGridView1.DataSource = new List<Customer> { customer };
                    }
                }
                else
                {
                    MessageBox.Show("Customer not found.");
                }
            }
            else
            {
                // Nếu không có từ khóa tìm kiếm, tải lại toàn bộ dữ liệu
                LoadCustomerData();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(UserSession.CurrentUserRole);
            form2.Show();
            this.Hide();
        }

        private void txtCustomerPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomerEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomerHouseNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomerCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomerPin_TextChanged(object sender, EventArgs e)
        {

        }
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            CheckFormValidity();
        }

        // Phương thức kiểm tra tính hợp lệ của form
        private void CheckFormValidity()
        {
            // Kiểm tra nếu tất cả các TextBox có dữ liệu
            bool isFormValid = !string.IsNullOrWhiteSpace(txtCustomerName.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerPhone.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerEmail.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerHouseNo.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerCity.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerPin.Text);

            button1.Enabled = isFormValid;
            button3.Enabled = isFormValid;
        }
        
    }
}
