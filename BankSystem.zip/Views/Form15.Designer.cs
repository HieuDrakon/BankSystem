﻿namespace _Banking.Views
{
    partial class Form15
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            label8 = new Label();
            label7 = new Label();
            label5 = new Label();
            txtCustomerPin = new TextBox();
            txtCustomerCity = new TextBox();
            txtCustomerEmail = new TextBox();
            txtCustomerHouseNo = new TextBox();
            Phone = new Label();
            label3 = new Label();
            label1 = new Label();
            txtCustomerPhone = new TextBox();
            txtCustomerName = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(12, 12);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 38;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(158, 318);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 37;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(48, 231);
            label8.Name = "label8";
            label8.Size = new Size(34, 20);
            label8.TabIndex = 36;
            label8.Text = "City";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(50, 267);
            label7.Name = "label7";
            label7.Size = new Size(32, 20);
            label7.TabIndex = 35;
            label7.Text = "PIN";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(48, 191);
            label5.Name = "label5";
            label5.Size = new Size(71, 20);
            label5.TabIndex = 34;
            label5.Text = "HouseNo";
            // 
            // txtCustomerPin
            // 
            txtCustomerPin.Location = new Point(158, 264);
            txtCustomerPin.Name = "txtCustomerPin";
            txtCustomerPin.Size = new Size(163, 27);
            txtCustomerPin.TabIndex = 33;
            // 
            // txtCustomerCity
            // 
            txtCustomerCity.Location = new Point(158, 231);
            txtCustomerCity.Name = "txtCustomerCity";
            txtCustomerCity.Size = new Size(163, 27);
            txtCustomerCity.TabIndex = 32;
            // 
            // txtCustomerEmail
            // 
            txtCustomerEmail.Location = new Point(158, 158);
            txtCustomerEmail.Name = "txtCustomerEmail";
            txtCustomerEmail.Size = new Size(163, 27);
            txtCustomerEmail.TabIndex = 31;
            // 
            // txtCustomerHouseNo
            // 
            txtCustomerHouseNo.Location = new Point(158, 191);
            txtCustomerHouseNo.Name = "txtCustomerHouseNo";
            txtCustomerHouseNo.Size = new Size(163, 27);
            txtCustomerHouseNo.TabIndex = 30;
            // 
            // Phone
            // 
            Phone.AutoSize = true;
            Phone.Location = new Point(48, 127);
            Phone.Name = "Phone";
            Phone.Size = new Size(104, 20);
            Phone.TabIndex = 29;
            Phone.Text = "PhoneNumber";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 94);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 28;
            label3.Text = "Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(48, 158);
            label1.Name = "label1";
            label1.Size = new Size(46, 20);
            label1.TabIndex = 27;
            label1.Text = "Email";
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.Location = new Point(158, 124);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.Size = new Size(163, 27);
            txtCustomerPhone.TabIndex = 26;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(158, 91);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(163, 27);
            txtCustomerName.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Highlight;
            label2.Location = new Point(207, 25);
            label2.Name = "label2";
            label2.Size = new Size(172, 46);
            label2.TabIndex = 39;
            label2.Text = "ĐĂNG KÝ ";
            // 
            // Form15
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.d52078bfddc4e60232af4e8846262446;
            ClientSize = new Size(603, 450);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(txtCustomerPin);
            Controls.Add(txtCustomerCity);
            Controls.Add(txtCustomerEmail);
            Controls.Add(txtCustomerHouseNo);
            Controls.Add(Phone);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(txtCustomerPhone);
            Controls.Add(txtCustomerName);
            Name = "Form15";
            Text = "Form15";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private Label label8;
        private Label label7;
        private Label label5;
        private TextBox txtCustomerPin;
        private TextBox txtCustomerCity;
        private TextBox txtCustomerEmail;
        private TextBox txtCustomerHouseNo;
        private Label Phone;
        private Label label3;
        private Label label1;
        private TextBox txtCustomerPhone;
        private TextBox txtCustomerName;
        private Label label2;
    }
}